import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def main():
    while True:
        print("\n=== BLAZING DEVELOPER TOOLS ===", flush=True)
        print("1. Live coordinate picker")
        print("2. Live raw OCR stream")
        print("Q. Quit")
        choice = input("Select tool: ").strip().lower()
        if choice in ("q", "quit", "exit"):
            return
        script = {"1": "coordinates.py", "2": "ocr.py"}.get(choice)
        if not script:
            print("Invalid selection")
            continue
        try:
            code = subprocess.call([sys.executable, "-u", str(HERE / script)])
            if code:
                print(f"[DEV] Tool exited with code {code}")
        except KeyboardInterrupt:
            print("\n[DEV] Tool stopped")

if __name__ == "__main__":
    main()
